import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface DetectionResult {
  sign: string;
  confidence: number;
  action: string;
  weather_condition: string;
  enhancement_applied: string[];
}

export async function detectTrafficSign(base64Image: string): Promise<DetectionResult | null> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        {
          parts: [
            {
              text: "Analyze this dashboard camera view. Detect any traffic signs (Stop, Speed Limit, Yield, etc.). Account for harsh weather (rain, fog, snow, low light). Provide a JSON response with the sign name, confidence (0-1), recommended driver action, current weather condition, and what digital enhancements (e.g., 'dehazing', 'contrast boost') would help visibility.",
            },
            {
              inlineData: {
                mimeType: "image/jpeg",
                data: base64Image,
              },
            },
          ],
        },
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            sign: { type: Type.STRING },
            confidence: { type: Type.NUMBER },
            action: { type: Type.STRING },
            weather_condition: { type: Type.STRING },
            enhancement_applied: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
          },
          required: ["sign", "confidence", "action", "weather_condition", "enhancement_applied"],
        },
      },
    });

    const result = JSON.parse(response.text || "null");
    return result;
  } catch (error) {
    console.error("Vision detection error:", error);
    return null;
  }
}
