import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Camera, 
  AlertTriangle, 
  Wind, 
  CloudRain, 
  Sun, 
  Moon, 
  ShieldCheck, 
  Volume2, 
  VolumeX,
  Settings,
  Activity,
  Maximize2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { detectTrafficSign, DetectionResult } from './services/visionService';
import { speak } from './services/voiceService';

export default function App() {
  const [isStarted, setIsStarted] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastDetection, setLastDetection] = useState<DetectionResult | null>(null);
  const [detectionHistory, setDetectionHistory] = useState<DetectionResult[]>([]);
  const [simulatedWeather, setSimulatedWeather] = useState<string | null>(null);
  const [weather, setWeather] = useState<string>("CALIBRATING...");
  const [fps, setFps] = useState(0);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const lastProcessedTime = useRef<number>(0);
  const frameCount = useRef<number>(0);
  const lastFpsUpdate = useRef<number>(0);

  const weatherStates = [
    { id: 'clear', label: 'Clear', icon: <Sun size={14} />, filter: '' },
    { id: 'rainy', label: 'Rainy', icon: <CloudRain size={14} />, filter: 'brightness(0.8) contrast(1.1)' },
    { id: 'snowy', label: 'Snowy', icon: <Wind size={14} />, filter: 'brightness(1.2) contrast(0.9)' },
    { id: 'night', label: 'Night', icon: <Moon size={14} />, filter: 'brightness(0.4) saturate(0.5)' },
  ];

  // Start Camera
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'environment',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsStarted(true);
      }
    } catch (err) {
      console.error("Camera access denied:", err);
    }
  };

  // FPS Counter
  useEffect(() => {
    const updateFps = () => {
      const now = performance.now();
      if (now - lastFpsUpdate.current >= 1000) {
        setFps(frameCount.current);
        frameCount.current = 0;
        lastFpsUpdate.current = now;
      }
      frameCount.current++;
      requestAnimationFrame(updateFps);
    };
    const anim = requestAnimationFrame(updateFps);
    return () => cancelAnimationFrame(anim);
  }, []);

  // Processing Loop
  const processFrame = useCallback(async () => {
    if (!isStarted || isProcessing || !videoRef.current || !canvasRef.current) return;

    const now = Date.now();
    // Process every 3 seconds to avoid API spam while maintaining "real-time" feel for traffic signs
    if (now - lastProcessedTime.current < 3000) return;

    setIsProcessing(true);
    lastProcessedTime.current = now;

    const canvas = canvasRef.current;
    const video = videoRef.current;
    const ctx = canvas.getContext('2d');

    if (ctx) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      // Apply "Enhancement" filters to the canvas before capture
      // If simulated weather is active, we apply the simulation filter to the capture
      const activeWeather = weatherStates.find(w => w.id === simulatedWeather);
      ctx.filter = activeWeather ? activeWeather.filter : 'contrast(1.2) brightness(1.1) saturate(1.1)';
      
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      const base64Image = canvas.toDataURL('image/jpeg', 0.7).split(',')[1];
      const result = await detectTrafficSign(base64Image);

      if (result) {
        const finalWeather = simulatedWeather ? simulatedWeather.toUpperCase() : result.weather_condition;
        const resultWithWeather = { ...result, weather_condition: finalWeather };
        
        setWeather(finalWeather);
        
        if (result.sign !== "none" && result.sign !== "unknown") {
          setLastDetection(resultWithWeather);
          setDetectionHistory(prev => [resultWithWeather, ...prev].slice(0, 5));
          
          if (!isMuted) {
            speak(`${result.sign}. ${result.action}`);
          }
        }
      }
    }
    setIsProcessing(false);
  }, [isStarted, isProcessing, isMuted, simulatedWeather]);

  useEffect(() => {
    const interval = setInterval(processFrame, 500);
    return () => clearInterval(interval);
  }, [processFrame]);

  return (
    <div className="relative h-screen w-screen bg-black flex flex-col overflow-hidden">
      {/* Background Video Feed */}
      <div className="absolute inset-0 z-0">
        <video 
          ref={videoRef} 
          autoPlay 
          playsInline 
          muted 
          style={{ filter: weatherStates.find(w => w.id === simulatedWeather)?.filter || 'none' }}
          className="h-full w-full object-cover opacity-60 grayscale-[0.2] transition-all duration-1000"
        />
        
        {/* Weather Simulation Overlays */}
        <div className={`weather-overlay weather-rain ${simulatedWeather === 'rainy' ? 'opacity-100' : 'opacity-0'}`} />
        <div className={`weather-overlay weather-snow ${simulatedWeather === 'snowy' ? 'opacity-100' : 'opacity-0'}`} />
        <div className={`weather-overlay weather-night ${simulatedWeather === 'night' ? 'opacity-100' : 'opacity-0'}`} />
        
        <canvas ref={canvasRef} className="hidden" />
        
        {/* HUD Overlays */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="scanline" />
          <div className="absolute inset-0 border-[20px] border-white/5" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 border border-emerald-500/20 rounded-full animate-pulse" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] border border-emerald-500/10 rounded-full" />
        </div>
      </div>

      {/* Top Bar */}
      <div className="relative z-10 p-6 flex justify-between items-start">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2 text-emerald-500">
            <ShieldCheck size={20} />
            <h1 className="font-bold tracking-tighter text-xl">AEGIS VISION v2.4</h1>
          </div>
          <div className="hud-text text-white/50">Adaptive Deep Learning Framework</div>
        </div>

        <div className="flex gap-4">
          {/* Weather Simulation Selector */}
          <div className="glass-panel p-1 flex gap-1">
            {weatherStates.map((ws) => (
              <button
                key={ws.id}
                onClick={() => setSimulatedWeather(ws.id === 'clear' ? null : ws.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl transition-all ${
                  (simulatedWeather === ws.id || (ws.id === 'clear' && !simulatedWeather))
                    ? 'bg-emerald-500 text-black font-bold'
                    : 'text-white/40 hover:text-white/80'
                }`}
              >
                {ws.icon}
                <span className="text-[10px] uppercase font-mono">{ws.label}</span>
              </button>
            ))}
          </div>

          <div className="glass-panel px-4 py-2 flex items-center gap-3">
            <div className="flex flex-col items-end">
              <span className="hud-text text-white/40">Weather State</span>
              <span className="text-sm font-mono text-emerald-400">{weather}</span>
            </div>
            <div className="p-2 bg-emerald-500/20 rounded-lg text-emerald-400">
              {weather.toLowerCase().includes('rain') ? <CloudRain size={18} /> : 
               weather.toLowerCase().includes('night') ? <Moon size={18} /> :
               weather.toLowerCase().includes('snow') ? <Wind size={18} /> : <Sun size={18} />}
            </div>
          </div>

          <button 
            onClick={() => setIsMuted(!isMuted)}
            className="glass-panel p-3 hover:bg-white/10 transition-colors text-white/80"
          >
            {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
          </button>
        </div>
      </div>

      {/* Main HUD Content */}
      <div className="relative z-10 flex-1 flex items-center justify-center pointer-events-none">
        <AnimatePresence mode="wait">
          {lastDetection && (
            <motion.div 
              key={lastDetection.sign}
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 1.1, y: -20 }}
              className="flex flex-col items-center gap-6"
            >
              <div className="relative">
                <div className="absolute -inset-8 bg-emerald-500/20 blur-3xl rounded-full animate-pulse" />
                <div className="w-32 h-32 border-4 border-emerald-500 rounded-2xl flex items-center justify-center bg-black/80 backdrop-blur-xl shadow-[0_0_50px_rgba(16,185,129,0.3)]">
                  <AlertTriangle size={64} className="text-emerald-500" />
                </div>
              </div>
              
              <div className="text-center">
                <motion.h2 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-4xl font-black tracking-tighter uppercase mb-2"
                >
                  {lastDetection.sign}
                </motion.h2>
                <p className="text-emerald-400 font-mono text-sm tracking-widest uppercase">
                  {lastDetection.action}
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Side Diagnostic Log */}
      <div className="absolute right-6 top-32 bottom-32 w-64 z-10 pointer-events-none flex flex-col gap-4">
        <div className="hud-text text-white/30 px-2">Detection History (Written State)</div>
        <div className="flex-1 overflow-hidden flex flex-col gap-2">
          <AnimatePresence initial={false}>
            {detectionHistory.map((log, i) => (
              <motion.div
                key={i + log.sign}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="glass-panel p-3 text-[9px] font-mono border-l-2 border-emerald-500/50"
              >
                <div className="text-emerald-400 font-bold mb-1">{log.sign}</div>
                <div className="text-white/60 mb-1">WEATHER: {log.weather_condition}</div>
                <div className="text-white/40 italic">ACTION: {log.action}</div>
                <div className="mt-1 flex flex-wrap gap-1">
                  {log.enhancement_applied.map(e => (
                    <span key={e} className="text-[7px] bg-white/5 px-1 rounded">{e}</span>
                  ))}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>

      {/* Bottom Controls & Stats */}
      <div className="relative z-10 p-8 grid grid-cols-3 items-end gap-8">
        {/* Left Stats */}
        <div className="flex flex-col gap-4">
          <div className="glass-panel p-4 flex flex-col gap-3">
            <div className="flex justify-between items-center">
              <span className="hud-text text-white/40">System Load</span>
              <span className="text-[10px] font-mono text-emerald-500">OPTIMAL</span>
            </div>
            <div className="h-1 bg-white/10 rounded-full overflow-hidden">
              <motion.div 
                className="h-full bg-emerald-500"
                animate={{ width: isProcessing ? '85%' : '30%' }}
              />
            </div>
            <div className="flex justify-between hud-text text-[8px] text-white/30">
              <span>LATENCY: {isProcessing ? '420ms' : '12ms'}</span>
              <span>FPS: {fps}</span>
            </div>
          </div>
        </div>

        {/* Center Start Button */}
        <div className="flex justify-center">
          {!isStarted ? (
            <button 
              onClick={startCamera}
              className="group relative px-8 py-4 bg-emerald-500 text-black font-bold rounded-xl overflow-hidden transition-all hover:scale-105 active:scale-95"
            >
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform" />
              <span className="relative flex items-center gap-2">
                <Camera size={20} />
                INITIALIZE AEGIS
              </span>
            </button>
          ) : (
            <div className="flex flex-col items-center gap-2">
              <div className="flex items-center gap-2 px-4 py-2 bg-emerald-500/10 border border-emerald-500/30 rounded-full">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-ping" />
                <span className="hud-text text-emerald-500">Live Monitoring Active</span>
              </div>
            </div>
          )}
        </div>

        {/* Right Enhancements */}
        <div className="flex flex-col gap-4 items-end">
          <div className="glass-panel p-4 w-full max-w-[240px]">
            <span className="hud-text text-white/40 mb-3 block">Active Enhancements</span>
            <div className="flex flex-wrap gap-2">
              {lastDetection?.enhancement_applied.map(e => (
                <span key={e} className="px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded text-[8px] font-mono text-emerald-400 uppercase">
                  {e}
                </span>
              )) || (
                <span className="text-[8px] font-mono text-white/20 italic">Waiting for detection...</span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Decorative Corners */}
      <div className="absolute top-0 left-0 w-16 h-16 border-t-2 border-l-2 border-emerald-500/30 pointer-events-none" />
      <div className="absolute top-0 right-0 w-16 h-16 border-t-2 border-r-2 border-emerald-500/30 pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-16 h-16 border-b-2 border-l-2 border-emerald-500/30 pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-16 h-16 border-b-2 border-r-2 border-emerald-500/30 pointer-events-none" />
    </div>
  );
}
